import SwiftUI

@main
struct ChickenFarmGameApp: App {
    var body: some Scene {
        WindowGroup {
            ChickenFarmGameInitialView()
        }
    }
}
